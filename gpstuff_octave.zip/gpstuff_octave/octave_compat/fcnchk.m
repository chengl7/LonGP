function f = fcnchk(x,n )
f=x;
end

