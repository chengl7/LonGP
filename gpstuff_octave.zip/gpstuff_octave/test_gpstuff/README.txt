This folder has tests for testing the GPstuff package with both octave and 
matlab. The tests can be run by running the script run_tests. The script runs 
specific demos to see that they run properly. Furthermore, the results from the
demos are compared to old results to check if the values have changed.